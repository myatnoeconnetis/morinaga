<footer>
	<div class="footerTop">
		<div class="ctInner">
			<!-- ftBannerBlock -->
			<div class="ftBannerBlock">
				<div class="ftImgGroup">
					<img src="assets/img/common/ft_logo.png" alt="footer">
					<img src="assets/img/common/ft_illustration.png" alt="footer illustration">
				</div>
				<div class="ftListGroup">
					<dl class="ftSitemap">
						<dt>
							<p>知識を広げる</p>
						</dt>
						<dd>
							<ul>
								<li>
									<a href="#">出張授業</a>
								</li>
								<li>
									<a href="#">森永製菓のキャラメル教室</a>
								</li>
								<li>
									<a href="#">森永1 チョコ for 1 スマイル 未来ラーニング</a>
								</li>
								<li>
									<a href="#">森永製菓のキャリア授業</a>
								</li>
								<li>
									<a href="#">森永製菓の菓子育<br>「メルとマールのピクニック」</a>
								</li>
								<li>
									<a href="#">実施校一覧（PDF）</a>
								</li>
								<li>
									<a href="#">活動レポート</a>
								</li>
							</ul>
							<ul>
								<li>
									<a href="#">MORIUM＆鶴見工場見学</a>
								</li>
								<li>
									<a href="#">キッザニア東京</a>
								</li>
								<li>
									<a href="#">プロギング</a>
								</li>
								<li>
									<a href="#">モリナガスマイルパーク</a>
								</li>
							</ul>
						</dd>
					</dl>
					<dl class="ftSitemap">
						<dt>
							<p>知識を広げる</p>
						</dt>
						<dd>
							<ul>
								<li>
									<a href="#">食のしごと</a>
								</li>
								<li>
									<a href="#">お菓子の記憶</a>
								</li>
								<li>
									<a href="#">医師と考える食育</a>
								</li>
								<li>
									<a href="#">食品表示</a>
								</li>
								<li>
									<a href="#">森永製菓の菓子育</a>
								</li>
								<li>
									<a href="#">アレルギー“だから” がないラボ</a>
								</li>
								<li>
									<a href="#">森永おくち研究所</a>
								</li>
								<li>
									<a href="#">バーチャル工場見学憶</a>
								</li>
							</ul>
						</dd>
					</dl>
					<dl class="ftSitemap">
						<dt>
							<p>関連リンク</p>
						</dt>
						<dd>
							<ul>
								<li>
									<a href="#">MORIUM＆鶴見工場見学</a>
								</li>
								<li>
									<a href="#">モリナガスマイルパーク</a>
								</li>
								<li>
									<a href="#">1 チョコ for 1 スマイル</a>
								</li>
								<li>
									<a href="#">キッザニア東京「お菓子工場」</a>
								</li>
								<li>
									<a href="#">アレルギー“だから” がないラボ</a>
								</li>
								<li>
									<a href="#">森永おくち研究所</a>
								</li>
								<li>
									<a href="#">バーチャル工場見学憶</a>
								</li>
								<li>
									<a href="#">対象別（年齢別）<br>コンテンツ紹介一覧</a>
								</li>
							</ul>
						</dd>
					</dl>
				</div>
			</div>
			<!-- /ftBannerBlock -->
		</div>

		<!-- ftBottomBlock -->
		<div class="ftBottomBlock">
			<img src="assets/img/common/footer_bottom.png" alt="footer">
		</div>
		<!-- /ftBottomBlock -->
	</div>
</footer>