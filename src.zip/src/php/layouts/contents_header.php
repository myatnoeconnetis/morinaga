<!-- header -->
<header id="header">
	<img src="assets/img/common/header_top.png" alt="">
	<div class="ctInner">
		<nav class="breadcrumbs">
			<ul>
				<li>
					<a href="#">ホーム</a>
				</li>
				<li>
					<a href="#">知る・楽しむ</a>
				</li>
				<li>
					<a href="#">食育・工場見学</a>
				</li>
				<li>
					<a href="#">森永製菓の食育</a>
				</li>
			</ul>
		</nav>
	</div>
</header>